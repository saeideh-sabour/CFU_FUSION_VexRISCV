
# Create Project

create_project -force -name digilent_nexys_video -part xc7a200t-sbg484-1
set_msg_config -id {Common 17-55} -new_severity {Warning}

# Add Sources

read_verilog {cfu.v}
read_verilog {VexRiscv_FullCfu.v}
read_verilog {digilent_nexys_video.v}

# Add EDIFs


# Add IPs


# Add constraints

read_xdc digilent_nexys_video.xdc
set_property PROCESSING_ORDER EARLY [get_files digilent_nexys_video.xdc]

# Add pre-synthesis commands


# Synthesis

synth_design -directive default -top digilent_nexys_video -part xc7a200t-sbg484-1

# Synthesis report

report_timing_summary -file digilent_nexys_video_timing_synth.rpt
report_utilization -hierarchical -file digilent_nexys_video_utilization_hierarchical_synth.rpt
report_utilization -file digilent_nexys_video_utilization_synth.rpt

# Optimize design

opt_design -directive default

# Add pre-placement commands


# Placement

place_design -directive default

# Placement report

report_utilization -hierarchical -file digilent_nexys_video_utilization_hierarchical_place.rpt
report_utilization -file digilent_nexys_video_utilization_place.rpt
report_io -file digilent_nexys_video_io.rpt
report_control_sets -verbose -file digilent_nexys_video_control_sets.rpt
report_clock_utilization -file digilent_nexys_video_clock_utilization.rpt

# Add pre-routing commands


# Routing

route_design -directive default
phys_opt_design -directive default
write_checkpoint -force digilent_nexys_video_route.dcp

# Routing report

report_timing_summary -no_header -no_detailed_paths
report_route_status -file digilent_nexys_video_route_status.rpt
report_drc -file digilent_nexys_video_drc.rpt
report_timing_summary -datasheet -max_paths 10 -file digilent_nexys_video_timing.rpt
report_power -file digilent_nexys_video_power.rpt
set_property BITSTREAM.CONFIG.SPI_BUSWIDTH 4 [current_design]

# Bitstream generation

write_bitstream -force digilent_nexys_video.bit 
write_cfgmem -force -format bin -interface spix4 -size 16 -loadbit "up 0x0 digilent_nexys_video.bit" -file digilent_nexys_video.bin

# End

quit