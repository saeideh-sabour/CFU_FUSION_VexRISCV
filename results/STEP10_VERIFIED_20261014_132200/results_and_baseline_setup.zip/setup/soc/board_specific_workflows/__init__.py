#!/usr/bin/env python3

from digilent_arty import DigilentArtySoCWorkflow
from digilent_nexys4ddr import DigilentNexys4DDRSoCWorkflow
from digilent_nexys_video import DigilentNexysVideoSoCWorkflow
from general import GeneralSoCWorkflow
from icebreaker import IcebreakerSoCWorkflow
from kosagi_fomu import KosagiFomuSoCWorkflow
from lattice_crosslink_nx_evn import LatticeCrossLinkNXEVNSoCWorkflow
from workflow_args import parse_workflow_args


def workflow_factory(target: str) -> GeneralSoCWorkflow:
    """Maps each board target to its appropriate build workflow."""

    return {
        "digilent_arty": DigilentArtySoCWorkflow,
        "digilent_nexys4ddr": DigilentNexys4DDRSoCWorkflow,
        "digilent_nexys_video": DigilentNexysVideoSoCWorkflow,
        "icebreaker": IcebreakerSoCWorkflow,
        "kosagi_fomu": KosagiFomuSoCWorkflow,
        "lattice_crosslink_nx_evn": LatticeCrossLinkNXEVNSoCWorkflow,
    }.get(target, GeneralSoCWorkflow)


__all__ = [
    "DigilentArtySoCWorkflow",
    "DigilentNexys4DDRSoCWorkflow",
    "GeneralSoCWorkflow",
    "IcebreakerSoCWorkflow",
    "KosagiFomuSoCWorkflow",
    "LatticeCrossLinkNXEVNSoCWorkflow",
    "parse_workflow_args",
    "workflow_factory",
]
