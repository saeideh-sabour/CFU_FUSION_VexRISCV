#!/usr/bin/env python3

import argparse
from typing import Callable

import general

from litex.build.xilinx import vivado
from litex.soc.integration import builder
from litex.soc.integration import soc as litex_soc
from litex.soc.integration import soc_core

from patch_cpu_variant import build_cpu_variant_if_needed


class DigilentNexysVideoSoCWorkflow(general.GeneralSoCWorkflow):

    def __init__(
        self,
        args: argparse.Namespace,
        soc_constructor: Callable[..., litex_soc.LiteXSoC],
        builder_constructor: Callable[..., builder.Builder] = None,
    ) -> None:

        if not args.sys_clk_freq:
            args.sys_clk_freq = 75_000_000
            print("INFO:Workflow:Nexys Video system clock set to 100MHz.")

        super().__init__(
            args,
            soc_constructor,
            builder_constructor,
        )


    def make_soc(self, **kwargs):

        soc_kwargs = {
            "with_ethernet": self.args.with_ethernet,
            "with_etherbone": self.args.with_etherbone,
            "with_video_framebuffer": self.args.with_video_framebuffer,
        }

        soc_kwargs.update(
            soc_core.soc_core_argdict(self.args)
        )

        if self.args.sys_clk_freq:
            soc_kwargs["sys_clk_freq"] = self.args.sys_clk_freq

        print(
            "INFO:Workflow:Nexys Video CPU variant:",
            self.args.cpu_variant,
        )

        build_cpu_variant_if_needed(
            self.args.cpu_variant
        )

        soc_kwargs.update(kwargs)

        return self.soc_constructor(**soc_kwargs)


    def build_soc(self, soc, **kwargs):

        if isinstance(
            soc.platform.toolchain,
            vivado.XilinxVivadoToolchain,
        ):
            kwargs.update(
                vivado.vivado_build_argdict(self.args)
            )

        return super().build_soc(
            soc,
            **kwargs,
        )
